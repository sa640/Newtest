import 'package:cloud_firestore/cloud_firestore.dart';

class Plasma {
  String name;
  String city;
  String mobileNo;
 

  Plasma({
    this.name,
    this.city,
    this.mobileNo,
  
  });
}
