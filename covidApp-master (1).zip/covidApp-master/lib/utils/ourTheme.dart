import 'package:flutter/material.dart';

/*class OurTheme {
  Color _lightBlack = Colors.cyan; //background color
  Color _lightGrey = Color.fromARGB(255, 119, 14, 15);
  Color _darkerGrey = Color.fromARGB(255, 119, 14, 15); //login
  //255, 120, 110, 190
//255, 67, 122, 155
//255, 119, 14, 15

  ThemeData buildTheme() {
    return ThemeData(
        canvasColor: _lightBlack,
        primaryColor: _lightBlack,
        accentColor: _lightGrey,
        secondaryHeaderColor: _darkerGrey,
        hintColor: _lightBlack,
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20.0),
            borderSide: BorderSide(
              color: _lightGrey,
            ),
          ),
        ),
        buttonTheme: ButtonThemeData(
            buttonColor: _darkerGrey,
            padding: EdgeInsets.symmetric(horizontal: 20.0),
            minWidth: 150,
            height: 40.0,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0))));
  }
}
*/